
!function(n){"use strict";n((function(){})),n(window).on("load",(function(){}))}(jQuery);